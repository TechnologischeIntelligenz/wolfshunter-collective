# WOLFSHUNTER COLLECTIVE app architecture

## Product decision

WOLFSHUNTER COLLECTIVE is primarily a retailer app. The olive-green retailer
workspace stays the main product surface:

`Discover → Favorites → Import List → explicit approval → Shopify DRAFT`

The app never publishes a product automatically. A retailer owns the final
review and publication decision in Shopify Admin.

## Fixed surface and hostname boundary

This boundary is a product decision and must not be collapsed into one Shopify
OAuth client or one embedded navigation:

| Surface | Canonical home | Authentication boundary |
| --- | --- | --- |
| WOLFSHUNTER operator/admin | `https://www.wolfshunter.com` | First-party WOLFSHUNTER admin authentication; not a Shopify merchant role |
| Retailer | Current Collective Shopify app and development shop | Retailer Shopify installation and retailer-scoped session |
| Supplier | Separate Supplier Shopify app at `https://supplier.collective.wolfshunter.com` | Separate Shopify Partner app/client ID and supplier-scoped session |

The operator/admin control plane must not ship as a production page inside the
retailer or supplier embedded app. The current `/app/admin` implementation is a
transitional development surface only; migrate the required controls to
`www.wolfshunter.com` before removing that route and before production launch.

## Two external roles, one operator boundary

Every connected merchant is treated as exactly one commercial role:

- **Retailer**: discovers supplier products and imports approved products into
  the retailer's Shopify store as DRAFTs.
- **Supplier**: maintains an eligible catalog, wholesale rules, media, and
  inventory for the Collective network.

The app operator/admin is not a merchant role. Its permanent control plane is
hosted at `www.wolfshunter.com` and uses a first-party server-side admin policy.
Retailer and supplier Shopify sessions never become operator sessions. During
the transition, the existing `APP_ADMIN_EMAILS` / `APP_ADMIN_SHOPS` allowlist
may protect the development-only `/app/admin` route, but that route is not the
final admin boundary.

## Deployment boundary

The current Shopify app configuration is the retailer app. `APP_ROLE=retailer`
is the safe default. The WOLFSHUNTER admin belongs to the separate WWW/APPHUB
deployment. The supplier surface is prepared in `shopify.app.supplier.toml`,
but it needs a second Shopify Partner app/client ID and its own production
hostname before it can be deployed.

This separation prevents supplier permissions, retailer product writes, and
operator controls from being mixed in one OAuth client or dashboard.

## Shared platform boundary

The future platform layer can be shared, but every record must carry its
tenant and role boundary. The minimum canonical objects are:

- supplier catalog product and variant;
- retailer catalog mapping and import approval;
- supplier price list and retailer margin policy;
- inventory snapshot with source and freshness;
- order/fulfillment events only after protected-data approval;
- audit and webhook delivery history.

AI may propose catalog text, mappings, diagnostics, and evidence-based risk
flags. It must not bypass tenant checks, Shopify authentication, retailer
approval, publication policy, human dispute review, or an appeal path. A
documented partner breach may trigger only the least-invasive reversible
protection permitted by a pre-approved policy; it may never be inferred from
protected characteristics or a black-box score.

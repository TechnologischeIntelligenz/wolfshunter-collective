import { DashboardView } from "../features/dashboard/dashboard-view";
import { authenticatedAppLoader } from "../services/authenticated-app-loader.server";

export { authenticatedAppLoader as loader };

export default function DashboardRoute() {
  return <DashboardView />;
}

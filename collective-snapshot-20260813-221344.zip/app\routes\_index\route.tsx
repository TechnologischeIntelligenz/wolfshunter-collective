import type { LoaderFunctionArgs, MetaFunction } from "react-router";
import { Form, redirect, useLoaderData } from "react-router";

import { login } from "../../shopify.server";
import styles from "./styles.module.css";

export const meta: MetaFunction = () => [
  { title: "WOLFSHUNTER COLLECTIVE — Premium Retailer & Fulfillment Network" },
  {
    name: "description",
    content:
      "WOLFSHUNTER COLLECTIVE — A premium retailer catalog, merchandising, and fulfillment network for Shopify merchants. Curate products, protect margins, and prepare fulfillment in a calm, commerce-native workspace.",
  },
];

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const url = new URL(request.url);

  if (url.searchParams.get("shop")) {
    throw redirect(`/app?${url.searchParams.toString()}`);
  }

  return { showForm: Boolean(login) };
};

export default function LandingRoute() {
  const { showForm } = useLoaderData<typeof loader>();

  return (
    <main className={styles.page}>
      <section className={styles.brandPanel}>
        <div className={styles.wordmark}>
          <span>W</span>
          <div>
            <strong>WOLFSHUNTER</strong>
            <small>COLLECTIVE</small>
          </div>
        </div>
        <div className={styles.statement}>
          <p className={styles.tagline}>Premium Retailer &amp; Fulfillment Network</p>
          <h1>Build an assortment with commercial discipline.</h1>
          <span>
            Curate supplier products, protect margins, and prepare fulfillment
            in a calm, commerce-native workspace for Shopify merchants.
          </span>
        </div>
        <div className={styles.principles}>
          <span>Tenant-first</span>
          <span>Policy-gated</span>
          <span>Merchant-controlled</span>
        </div>
      </section>

      <section className={styles.accessPanel}>
        <div className={styles.accessCard}>
          <p className={styles.eyebrow}>Retailer access</p>
          <h2>Open your Collective workspace.</h2>
          <p className={styles.copy}>
            Enter your Shopify store domain to continue through Shopify&apos;s secure
            installation and authentication flow.
          </p>
          {showForm ? (
            <Form className={styles.form} method="post" action="/auth/login">
              <label className={styles.label}>
                <span>Shop domain</span>
                <input
                  className={styles.input}
                  type="text"
                  name="shop"
                  placeholder="your-store.myshopify.com"
                  autoComplete="url"
                  required
                />
              </label>
              <button className={styles.button} type="submit">
                Continue with Shopify
              </button>
            </Form>
          ) : null}
          <div className={styles.safetyNote}>
            <span aria-hidden="true" />
            <p>Phase 1 foundation — no product, order, inventory, or fulfillment writes.</p>
          </div>
        </div>
      </section>
    </main>
  );
}

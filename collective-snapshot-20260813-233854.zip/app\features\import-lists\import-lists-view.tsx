import { Link } from "react-router";

import { EmptyState, FoundationNotice, PageHeader, SectionHeading, StatusPill } from "../../components/collective/foundation";

const workflow = [
  ["01", "Discover", "Find eligible supplier products"],
  ["02", "Favorite", "Save a considered shortlist"],
  ["03", "Import list", "Group products by launch or collection"],
  ["04", "Edit", "Normalize titles, copy, media, and SEO"],
  ["05", "Select variants", "Choose only commercially relevant options"],
  ["06", "Pricing", "Review margin policy and recommended retail"],
  ["07", "Preview", "Validate the exact DRAFT product payload"],
  ["08", "Push to store", "Future approval-gated Shopify mutation"],
] as const;

export function ImportListsView() {
  return (
    <main className="collective-page">
      <PageHeader
        eyebrow="Controlled product staging"
        title="Import Lists"
        description="Shape assortments in a reviewable workspace before any Shopify product exists."
        actions={
          <Link className="collective-button collective-button-secondary" to="/app/discover">
            Browse catalog
          </Link>
        }
      />
      <FoundationNotice>
        Product push is unavailable. The eventual Shopify product state is DRAFT by default.
      </FoundationNotice>

      <section className="collective-section collective-workflow-section">
        <SectionHeading
          title="A deliberate import workflow"
          description="Every stage remains reversible until a future policy-gated product push."
          accessory={<StatusPill tone="info">No Shopify writes</StatusPill>}
        />
        <ol className="collective-workflow-grid">
          {workflow.map(([number, title, description], index) => (
            <li key={title} className={index === workflow.length - 1 ? "is-locked" : ""}>
              <span>{number}</span>
              <div>
                <h3>{title}</h3>
                <p>{description}</p>
              </div>
            </li>
          ))}
        </ol>
      </section>

      <EmptyState
        eyebrow="No import lists yet"
        title="Start with a product, not a spreadsheet."
        description="Add a fixture product from Discover when you are ready to test the staging experience. Persistence and Shopify push arrive in later phases."
        actionLabel="Open Discover"
        actionHref="/app/discover"
      />
    </main>
  );
}

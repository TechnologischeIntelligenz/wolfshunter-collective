import type { LoaderFunctionArgs } from "react-router";

import { authenticate } from "../shopify.server";

export interface AuthenticatedAppLoaderData {
  authLink: string;
  sessionType: string;
  shop: string;
}

export async function authenticatedAppLoader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);

  return {
    authLink: `/auth/login?shop=${encodeURIComponent(session.shop)}`,
    sessionType: session.isOnline ? "Online session" : "Offline session",
    shop: session.shop,
  } satisfies AuthenticatedAppLoaderData;
}

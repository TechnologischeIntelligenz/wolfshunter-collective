import { FoundationRouteView } from "../features/foundation/foundation-route-view";
import { authenticatedAppLoader } from "../services/authenticated-app-loader.server";

export { authenticatedAppLoader as loader };

export default function SettingsRoute() {
  return (
    <FoundationRouteView
      eyebrow="Retailer configuration"
      title="Settings"
      description="Tenant profile, market, warehouse, margin, and approval policies will be configured here."
      emptyTitle="No retailer settings are connected."
      emptyDescription="Authentication, merchant configuration, and live permissions remain unchanged in Phase 1."
    />
  );
}

import { FoundationRouteView } from "../features/foundation/foundation-route-view";
import { authenticatedAppLoader } from "../services/authenticated-app-loader.server";

export { authenticatedAppLoader as loader };

export default function MyProductsRoute() {
  return (
    <FoundationRouteView
      eyebrow="Retailer catalog"
      title="My Products"
      description="A mapped view of staged, draft, and eventually live Collective products."
      emptyTitle="No Collective products have been pushed."
      emptyDescription="Phase 1 does not create Shopify products. Future imports will remain DRAFT until a merchant deliberately publishes them."
    />
  );
}

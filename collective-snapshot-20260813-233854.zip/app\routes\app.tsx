import type { ReactNode } from "react";
import type { HeadersFunction, LoaderFunctionArgs } from "react-router";
import {
  Link,
  Outlet,
  useLoaderData,
  useLocation,
  useRouteError,
} from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { AppProvider } from "@shopify/shopify-app-react-router/react";
import { NavMenu } from "@shopify/app-bridge-react";

import { authenticate } from "../shopify.server";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  await authenticate.admin(request);

  // eslint-disable-next-line no-undef
  return { apiKey: process.env.SHOPIFY_API_KEY || "" };
};

function AppNavLink({
  children,
  to,
  home = false,
}: {
  children: ReactNode;
  to: string;
  home?: boolean;
}) {
  const location = useLocation();
  const target = location.search ? `${to}${location.search}` : to;

  return (
    <Link to={target} rel={home ? "home" : undefined}>
      {children}
    </Link>
  );
}

export default function App() {
  const { apiKey } = useLoaderData<typeof loader>();

  return (
    <AppProvider embedded apiKey={apiKey}>
      <NavMenu>
        <AppNavLink home to="/app">
          Dashboard
        </AppNavLink>
        <AppNavLink to="/app/discover">Discover</AppNavLink>
        <AppNavLink to="/app/favorites">Favorites</AppNavLink>
        <AppNavLink to="/app/import-lists">Import Lists</AppNavLink>
        <AppNavLink to="/app/my-products">My Products</AppNavLink>
        <AppNavLink to="/app/orders">Orders</AppNavLink>
        <AppNavLink to="/app/fulfillment">Fulfillment</AppNavLink>
        <AppNavLink to="/app/tracking">Tracking</AppNavLink>
        <AppNavLink to="/app/analytics">Analytics</AppNavLink>
        <AppNavLink to="/app/subscription">Subscription</AppNavLink>
        <AppNavLink to="/app/settings">Settings</AppNavLink>
      </NavMenu>
      <Outlet />
    </AppProvider>
  );
}

// Shopify needs React Router to catch some thrown responses, so that their headers are included in the response.
export function ErrorBoundary() {
  return boundary.error(useRouteError());
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};

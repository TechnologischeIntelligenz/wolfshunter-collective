import { FavoritesView } from "../features/favorites/favorites-view";
import { authenticatedAppLoader } from "../services/authenticated-app-loader.server";

export { authenticatedAppLoader as loader };

export default function FavoritesRoute() {
  return <FavoritesView />;
}

import { FoundationRouteView } from "../features/foundation/foundation-route-view";
import { authenticatedAppLoader } from "../services/authenticated-app-loader.server";

export { authenticatedAppLoader as loader };

export default function OrdersRoute() {
  return (
    <FoundationRouteView
      eyebrow="Network Orders"
      title="Orders"
      description="Mapped retailer lines will become tenant-isolated Network Orders in a future backend phase."
      emptyTitle="No retailer order data is connected."
      emptyDescription="Customer and order data remain completely outside this local design phase."
    />
  );
}

import { useLoaderData } from "react-router";

import { DashboardView } from "../features/dashboard/dashboard-view";
import { authenticatedAppLoader } from "../services/authenticated-app-loader.server";

export { authenticatedAppLoader as loader };

export default function DashboardRoute() {
  const loaderData = useLoaderData<typeof authenticatedAppLoader>();

  return <DashboardView {...loaderData} />;
}

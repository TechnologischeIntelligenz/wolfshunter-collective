import { useMemo, useState } from "react";

import { EmptyState, FoundationNotice, PageHeader } from "../../components/collective/foundation";
import { ProductCard } from "../../components/collective/product-card";
import { createPhaseOneFixtureState } from "../../services/merchandising/fixtures";
import { createRecommendationProvider } from "../../services/merchandising/rule-based-provider";

export function FavoritesView() {
  const fixture = useMemo(() => createPhaseOneFixtureState(), []);
  const provider = useMemo(() => createRecommendationProvider(), []);
  const [favoriteIds, setFavoriteIds] = useState(fixture.affinity.favoriteProductIds);
  const [stagedIds, setStagedIds] = useState<string[]>([]);

  const products = useMemo(
    () =>
      provider
        .recommend({
          tenant: fixture.tenant,
          products: fixture.catalog.filter((product) => favoriteIds.includes(product.id)),
          affinity: { ...fixture.affinity, favoriteProductIds: favoriteIds },
          sort: "RECOMMENDED",
        })
        .products,
    [favoriteIds, fixture.affinity, fixture.catalog, fixture.tenant, provider],
  );

  return (
    <main className="collective-page">
      <PageHeader
        eyebrow="Retailer shortlist"
        title="Favorites"
        description="A quiet place to collect products before building a deliberate assortment."
      />
      <FoundationNotice>
        Heart interactions are local fixture state only. Tenant persistence is prepared for a later backend phase.
      </FoundationNotice>

      {products.length ? (
        <section className="collective-product-grid collective-product-grid-favorites">
          {products.map((rankedProduct) => (
            <ProductCard
              key={rankedProduct.product.id}
              rankedProduct={rankedProduct}
              favorite
              staged={stagedIds.includes(rankedProduct.product.id)}
              onToggleFavorite={() =>
                setFavoriteIds((current) =>
                  current.filter((id) => id !== rankedProduct.product.id),
                )
              }
              onToggleImportList={() =>
                setStagedIds((current) =>
                  current.includes(rankedProduct.product.id)
                    ? current.filter((id) => id !== rankedProduct.product.id)
                    : [...current, rankedProduct.product.id],
                )
              }
            />
          ))}
        </section>
      ) : (
        <EmptyState
          eyebrow="Your private edit"
          title="Save only what earns a second look."
          description="Favorite products in Discover to build a focused shortlist. Nothing is imported or pushed to Shopify."
          actionLabel="Discover products"
          actionHref="/app/discover"
        />
      )}
    </main>
  );
}

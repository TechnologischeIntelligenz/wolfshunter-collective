import { DiscoverView } from "../features/discover/discover-view";
import { authenticatedAppLoader } from "../services/authenticated-app-loader.server";

export { authenticatedAppLoader as loader };

export default function DiscoverRoute() {
  return <DiscoverView />;
}

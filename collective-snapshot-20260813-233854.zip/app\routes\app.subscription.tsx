import { FoundationRouteView } from "../features/foundation/foundation-route-view";
import { authenticatedAppLoader } from "../services/authenticated-app-loader.server";

export { authenticatedAppLoader as loader };

export default function SubscriptionRoute() {
  return (
    <FoundationRouteView
      eyebrow="Account plan"
      title="Subscription"
      description="A future home for transparent plan limits, entitlements, and invoices."
      emptyTitle="Billing is not active."
      emptyDescription="Phase 1 creates no Shopify billing charge, trial, or production subscription."
    />
  );
}

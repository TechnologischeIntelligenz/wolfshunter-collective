import { FulfillmentView } from "../features/fulfillment/fulfillment-view";
import { authenticatedAppLoader } from "../services/authenticated-app-loader.server";

export { authenticatedAppLoader as loader };

export default function FulfillmentRoute() {
  return <FulfillmentView />;
}

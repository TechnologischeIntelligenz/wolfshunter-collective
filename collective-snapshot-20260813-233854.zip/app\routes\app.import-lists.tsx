import { ImportListsView } from "../features/import-lists/import-lists-view";
import { authenticatedAppLoader } from "../services/authenticated-app-loader.server";

export { authenticatedAppLoader as loader };

export default function ImportListsRoute() {
  return <ImportListsView />;
}

import fs from "node:fs";
import { createRequire } from "node:module";
import path from "node:path";
import { pathToFileURL } from "node:url";

// Load local configuration for `npm start` without printing secrets. Existing
// process environment values always win, which keeps hosted deployments safe.
const envPath = path.resolve(process.cwd(), ".env");
if (fs.existsSync(envPath)) {
  for (const line of fs.readFileSync(envPath, "utf8").split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (!match || match[1].startsWith("#")) continue;

    const [, key, rawValue] = match;
    const value = rawValue.replace(/^(["'])(.*)\1$/, "$2");
    if (process.env[key] === undefined) process.env[key] = value;
  }
}

process.env.NODE_ENV ??= "production";

const require = createRequire(import.meta.url);
const servePackageJson = require.resolve("@react-router/serve/package.json");
const serveBin = path.join(path.dirname(servePackageJson), "bin.js");
await import(pathToFileURL(serveBin).href);

import { useMemo, useState } from "react";
import { useFetcher, useLocation } from "react-router";

import { FoundationNotice, PageHeader } from "../../components/collective/foundation";
import { ProductCard } from "../../components/collective/product-card";
import { ProductImageStage } from "../../components/collective/product-image-stage";
import { createPhaseOneFixtureState } from "../../services/merchandising/fixtures";
import { createRecommendationProvider } from "../../services/merchandising/rule-based-provider";
import {
  RECOMMENDATION_BUCKET_LABELS,
  type CatalogSort,
  type RankedProduct,
  type RecommendationBucket,
} from "../../services/merchandising/types";

const sortLabels: Record<CatalogSort, string> = {
  RECOMMENDED: "Recommended",
  HIGHEST_MARGIN: "Highest margin",
  FASTEST_DELIVERY: "Fastest delivery",
  HIGHEST_STOCK: "Highest stock",
  NEWEST: "Newest",
  LOWEST_WHOLESALE_PRICE: "Lowest wholesale price",
};

const bucketOrder: RecommendationBucket[] = [
  "RECOMMENDED_FOR_STORE",
  "FAST_SHIPPING",
  "HIGH_MARGIN",
  "NEW_ARRIVALS",
  "PREMIUM_SELECTION",
];

export function DiscoverView({
  compact = false,
  initialFavoriteIds = [],
  initialImportedIds = [],
}: {
  compact?: boolean;
  initialFavoriteIds?: string[];
  initialImportedIds?: string[];
}) {
  const fixture = useMemo(() => createPhaseOneFixtureState(), []);
  const provider = useMemo(() => createRecommendationProvider(), []);
  const [sort, setSort] = useState<CatalogSort>("RECOMMENDED");
  const [bucket, setBucket] = useState<RecommendationBucket>(
    "RECOMMENDED_FOR_STORE",
  );
  const [favoriteIds, setFavoriteIds] = useState(initialFavoriteIds);
  const [stagedIds, setStagedIds] = useState(initialImportedIds);
  const [selectedProduct, setSelectedProduct] = useState<RankedProduct | null>(null);
  const fetcher = useFetcher();
  const location = useLocation();

  const persistWorkspaceChange = (
    intent: "favorite" | "import",
    productId: string,
    selected: boolean,
  ) => {
    fetcher.submit(
      { intent, productId, selected: String(selected) },
      {
        method: "post",
        action: `${location.pathname}${location.search}`,
      },
    );
  };

  const affinity = useMemo(
    () => ({ ...fixture.affinity, favoriteProductIds: favoriteIds }),
    [favoriteIds, fixture.affinity],
  );

  const recommendations = useMemo(
    () =>
      provider.recommend({
        tenant: fixture.tenant,
        products: fixture.catalog,
        affinity,
        bucket,
        sort,
      }),
    [affinity, bucket, fixture.catalog, fixture.tenant, provider, sort],
  );

  const bucketCounts = useMemo(
    () =>
      Object.fromEntries(
        bucketOrder.map((candidate) => [
          candidate,
          provider.recommend({
            tenant: fixture.tenant,
            products: fixture.catalog,
            affinity,
            bucket: candidate,
            sort: "RECOMMENDED",
          }).products.length,
        ]),
      ) as Record<RecommendationBucket, number>,
    [affinity, fixture.catalog, fixture.tenant, provider],
  );

  const toggleFavorite = (id: string) => {
    const selected = !favoriteIds.includes(id);
    setFavoriteIds((current) =>
      selected
        ? [...current, id]
        : current.filter((candidate) => candidate !== id),
    );
    persistWorkspaceChange("favorite", id, selected);
  };

  const toggleImportList = (id: string) => {
    const selected = !stagedIds.includes(id);
    setStagedIds((current) =>
      selected
        ? [...current, id]
        : current.filter((candidate) => candidate !== id),
    );
    persistWorkspaceChange("import", id, selected);
  };

  return (
    <main className={`collective-page ${compact ? "collective-page-compact" : ""}`}>
      <PageHeader
        eyebrow="Curated supplier catalog"
        title="Discover products worth carrying."
        description="Transparent economics, delivery context, and evidence-based merchandising signals before anything reaches your store."
        actions={
          <div className="collective-list-counter" aria-live="polite">
            <small>Import list</small>
            <strong>{stagedIds.length} staged</strong>
          </div>
        }
      />

      <FoundationNotice>
        Catalog ranking is deterministic. Add products to the Import List first; Shopify writes happen only through an explicit DRAFT action there.
      </FoundationNotice>

      <section className="collective-catalog-toolbar" aria-label="Catalog controls">
        <div className="collective-bucket-tabs" role="tablist" aria-label="Recommendation buckets">
          {bucketOrder.map((candidate) => (
            <button
              key={candidate}
              type="button"
              role="tab"
              aria-selected={bucket === candidate}
              className={bucket === candidate ? "is-active" : ""}
              onClick={() => setBucket(candidate)}
            >
              <span>{RECOMMENDATION_BUCKET_LABELS[candidate]}</span>
              <small>{bucketCounts[candidate]}</small>
            </button>
          ))}
        </div>
        <label className="collective-sort-control">
          <span>Sort</span>
          <select value={sort} onChange={(event) => setSort(event.target.value as CatalogSort)}>
            {Object.entries(sortLabels).map(([value, label]) => (
              <option key={value} value={value}>
                {label}
              </option>
            ))}
          </select>
        </label>
      </section>

      <div className="collective-catalog-meta">
        <span>
          {recommendations.products.length} catalog products · {sortLabels[sort]}
        </span>
        <span>Provider: evidence rules</span>
      </div>

      {recommendations.products.length ? (
        <section className="collective-product-grid" aria-label="Catalog products">
          {recommendations.products.map((rankedProduct) => (
            <ProductCard
              key={rankedProduct.product.id}
              rankedProduct={rankedProduct}
              favorite={favoriteIds.includes(rankedProduct.product.id)}
              staged={stagedIds.includes(rankedProduct.product.id)}
              onToggleFavorite={() => toggleFavorite(rankedProduct.product.id)}
              onToggleImportList={() => toggleImportList(rankedProduct.product.id)}
              onViewDetails={() => setSelectedProduct(rankedProduct)}
            />
          ))}
        </section>
      ) : (
        <div className="collective-inline-empty">
          <strong>No catalog products meet this rule.</strong>
          <span>Try another merchandising bucket.</span>
        </div>
      )}

      {selectedProduct ? (
        <div className="collective-detail-backdrop" role="presentation">
          <section
            className="collective-product-detail"
            role="dialog"
            aria-modal="true"
            aria-labelledby="collective-product-detail-title"
          >
            <button
              type="button"
              className="collective-detail-close"
              onClick={() => setSelectedProduct(null)}
              aria-label="Close product details"
            >
              ×
            </button>
            <ProductImageStage
              src={selectedProduct.product.imageUrl}
              alt={selectedProduct.product.title}
              imageCount={selectedProduct.product.imageCount}
              eager
            />
            <div className="collective-detail-copy">
              <p className="collective-eyebrow">{selectedProduct.product.category}</p>
              <h2 id="collective-product-detail-title">
                {selectedProduct.product.title}
              </h2>
              <p>
                This product view exposes the exact evidence inputs. It never
                claims popularity, trending status, or sales performance without
                verified data.
              </p>
              <dl className="collective-score-breakdown">
                {Object.entries(selectedProduct.score.breakdown).map(([label, value]) => (
                  <div key={label}>
                    <dt>{label.replace(/([A-Z])/g, " $1")}</dt>
                    <dd>{value}</dd>
                  </div>
                ))}
              </dl>
              <div className="collective-detail-reasons">
                {selectedProduct.score.reasons.map((reason) => (
                  <span key={reason}>{reason}</span>
                ))}
              </div>
              <p className="collective-detail-note">
                Imports are created as Shopify DRAFT products only after explicit review in Import Lists. Publication is never automatic.
              </p>
            </div>
          </section>
        </div>
      ) : null}
    </main>
  );
}

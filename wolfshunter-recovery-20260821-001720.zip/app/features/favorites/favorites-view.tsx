import { useMemo, useState } from "react";
import { useFetcher, useLocation } from "react-router";

import { EmptyState, FoundationNotice, PageHeader } from "../../components/collective/foundation";
import { ProductCard } from "../../components/collective/product-card";
import { createPhaseOneFixtureState } from "../../services/merchandising/fixtures";
import { createRecommendationProvider } from "../../services/merchandising/rule-based-provider";

export function FavoritesView({
  initialFavoriteIds = [],
  initialImportedIds = [],
}: {
  initialFavoriteIds?: string[];
  initialImportedIds?: string[];
}) {
  const fixture = useMemo(() => createPhaseOneFixtureState(), []);
  const provider = useMemo(() => createRecommendationProvider(), []);
  const [favoriteIds, setFavoriteIds] = useState(initialFavoriteIds);
  const [stagedIds, setStagedIds] = useState(initialImportedIds);
  const fetcher = useFetcher();
  const location = useLocation();

  const persistWorkspaceChange = (
    intent: "favorite" | "import",
    productId: string,
    selected: boolean,
  ) => {
    fetcher.submit(
      { intent, productId, selected: String(selected) },
      {
        method: "post",
        action: `${location.pathname}${location.search}`,
      },
    );
  };

  const products = useMemo(
    () =>
      provider
        .recommend({
          tenant: fixture.tenant,
          products: fixture.catalog.filter((product) => favoriteIds.includes(product.id)),
          affinity: { ...fixture.affinity, favoriteProductIds: favoriteIds },
          sort: "RECOMMENDED",
        })
        .products,
    [favoriteIds, fixture.affinity, fixture.catalog, fixture.tenant, provider],
  );

  return (
    <main className="collective-page">
      <PageHeader
        eyebrow="Retailer shortlist"
        title="Favorites"
        description="A quiet place to collect products before building a deliberate assortment."
      />
      <FoundationNotice>
        Favorites and Import List selections are saved to this retailer workspace. Product creation still requires an explicit DRAFT action in Import Lists.
      </FoundationNotice>

      {products.length ? (
        <section className="collective-product-grid collective-product-grid-favorites">
          {products.map((rankedProduct) => (
            <ProductCard
              key={rankedProduct.product.id}
              rankedProduct={rankedProduct}
              favorite
              staged={stagedIds.includes(rankedProduct.product.id)}
              onToggleFavorite={() =>
                (() => {
                  setFavoriteIds((current) =>
                    current.filter((id) => id !== rankedProduct.product.id),
                  );
                  persistWorkspaceChange("favorite", rankedProduct.product.id, false);
                })()
              }
              onToggleImportList={() =>
                (() => {
                  const selected = !stagedIds.includes(rankedProduct.product.id);
                  setStagedIds((current) =>
                    selected
                      ? [...current, rankedProduct.product.id]
                      : current.filter((id) => id !== rankedProduct.product.id),
                  );
                  persistWorkspaceChange("import", rankedProduct.product.id, selected);
                })()
              }
            />
          ))}
        </section>
      ) : (
        <EmptyState
          eyebrow="Your private edit"
          title="Save only what earns a second look."
          description="Favorite products in Discover to build a focused shortlist. Nothing is imported or pushed to Shopify."
          actionLabel="Discover products"
          actionHref="/app/discover"
        />
      )}
    </main>
  );
}

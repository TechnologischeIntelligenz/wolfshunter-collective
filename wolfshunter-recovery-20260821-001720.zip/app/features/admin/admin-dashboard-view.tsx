import { Link } from "react-router";

import {
  FoundationNotice,
  MetricCard,
  PageHeader,
  SectionHeading,
  StatusPill,
} from "../../components/collective/foundation";
import type { AuthenticatedAppLoaderData } from "../../services/authenticated-app-loader.server";

export function AdminDashboardView({
  shop,
  sessionType,
  shopMetrics,
  collectiveImportDrafts,
  collectiveImportFailures,
  diagnostics,
}: AuthenticatedAppLoaderData) {
  const metrics = [
    ["Connected shop", shop, "Current authenticated tenant"],
    ["Shopify products", shopMetrics.totalProducts ? `${shopMetrics.totalProducts.count}${shopMetrics.totalProducts.precision === "EXACT" ? "" : "+"}` : "—", "Read-only live count"],
    ["Shopify DRAFTs", shopMetrics.draftProducts ? `${shopMetrics.draftProducts.count}${shopMetrics.draftProducts.precision === "EXACT" ? "" : "+"}` : "—", "Unpublished merchant products"],
    ["Collective DRAFTs", String(collectiveImportDrafts), "Created through approved import flow"],
    ["Import failures", String(collectiveImportFailures), collectiveImportFailures ? "Needs operator review" : "No failures recorded"],
    ["Session", sessionType, "Authenticated server session"],
  ] as const;

  return (
    <main className="collective-page">
      <PageHeader
        eyebrow="Operator control plane"
        title="WOLFSHUNTER administration"
        description="Your operator dashboard is separate from the retailer workspace. Review health, imports, policy boundaries, and the connected shop without exposing these controls to retailers."
        actions={
          <>
            <StatusPill tone="positive">Admin allowlist</StatusPill>
            <Link className="collective-button collective-button-secondary" to="/app/admin">
              Admin controls
            </Link>
          </>
        }
      />

      <FoundationNotice>
        This view is protected by the server-side admin allowlist. Retailers
        continue to see the olive-green Discover, Import Lists, and DRAFT-first
        workspace for their own shop only. Supplier SKU mappings stay available
        only to this admin context and to the supplier that owns each mapping.
      </FoundationNotice>

      <section className="collective-section">
        <SectionHeading
          title="Operator overview"
          description="Only verified data from the currently connected Shopify shop is shown here."
          accessory={<StatusPill tone={diagnostics.overallTone === "green" ? "positive" : "attention"}>{diagnostics.overallTone}</StatusPill>}
        />
        <div className="collective-metric-grid">
          {metrics.map(([label, value, detail]) => (
            <MetricCard key={label} label={label} value={value} detail={detail} />
          ))}
        </div>
      </section>

      <section className="collective-dashboard-callout">
        <div>
          <p className="collective-eyebrow">Role separation</p>
          <h2>Supplier access remains a separate app.</h2>
          <p>
            Supplier catalog and inventory permissions belong to the future
            supplier Partner app. They are not granted to this retailer app or
            to retailer shops.
          </p>
        </div>
        <div className="collective-mini-flow" aria-label="Role separation flow">
          <span>Admin</span>
          <i>→</i>
          <span>Retailer app</span>
          <i>→</i>
          <span>Supplier app</span>
        </div>
      </section>
    </main>
  );
}

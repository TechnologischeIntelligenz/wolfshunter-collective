import db from "../db.server";

type AdminLike = {
  graphql: (
    query: string,
    options?: { variables?: Record<string, unknown> },
  ) => Promise<Response>;
};

export interface RetailerOrderRecord {
  id: number;
  shopifyOrderId: string;
  orderNumber: string | null;
  createdAt: string;
  shopifyUpdatedAt: string | null;
  financialStatus: string | null;
  fulfillmentStatus: string | null;
  currency: string | null;
  totalPrice: number | null;
  lineItemCount: number;
  syncStatus: string;
  lastEvent: string | null;
}

type OrderInput = {
  shopifyOrderId: string;
  orderNumber?: string | null;
  createdAt?: string | null;
  shopifyUpdatedAt?: string | null;
  financialStatus?: string | null;
  fulfillmentStatus?: string | null;
  currency?: string | null;
  totalPrice?: number | null;
  lineItemCount?: number;
  lastEvent?: string | null;
};

function asDate(value: string | null | undefined, fallback = new Date()) {
  if (!value) return fallback;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? fallback : date;
}

function asNumber(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && Number.isFinite(Number(value))) return Number(value);
  return null;
}

function toRecord(order: {
  id: number;
  shopifyOrderId: string;
  orderNumber: string | null;
  createdAt: Date;
  shopifyUpdatedAt: Date | null;
  financialStatus: string | null;
  fulfillmentStatus: string | null;
  currency: string | null;
  totalPrice: number | null;
  lineItemCount: number;
  syncStatus: string;
  lastEvent: string | null;
}): RetailerOrderRecord {
  return {
    id: order.id,
    shopifyOrderId: order.shopifyOrderId,
    orderNumber: order.orderNumber,
    createdAt: order.createdAt.toISOString(),
    shopifyUpdatedAt: order.shopifyUpdatedAt?.toISOString() ?? null,
    financialStatus: order.financialStatus,
    fulfillmentStatus: order.fulfillmentStatus,
    currency: order.currency,
    totalPrice: order.totalPrice,
    lineItemCount: order.lineItemCount,
    syncStatus: order.syncStatus,
    lastEvent: order.lastEvent,
  };
}

export async function upsertRetailerOrder(shop: string, input: OrderInput) {
  const order = await db.retailerOrder.upsert({
    where: {
      shop_shopifyOrderId: {
        shop,
        shopifyOrderId: input.shopifyOrderId,
      },
    },
    create: {
      shop,
      shopifyOrderId: input.shopifyOrderId,
      orderNumber: input.orderNumber ?? null,
      createdAt: asDate(input.createdAt),
      shopifyUpdatedAt: input.shopifyUpdatedAt ? asDate(input.shopifyUpdatedAt) : null,
      financialStatus: input.financialStatus ?? null,
      fulfillmentStatus: input.fulfillmentStatus ?? null,
      currency: input.currency ?? null,
      totalPrice: input.totalPrice ?? null,
      lineItemCount: input.lineItemCount ?? 0,
      syncStatus: "SYNCED",
      lastEvent: input.lastEvent ?? null,
    },
    update: {
      orderNumber: input.orderNumber ?? undefined,
      createdAt: input.createdAt ? asDate(input.createdAt) : undefined,
      shopifyUpdatedAt: input.shopifyUpdatedAt ? asDate(input.shopifyUpdatedAt) : undefined,
      financialStatus: input.financialStatus ?? undefined,
      fulfillmentStatus: input.fulfillmentStatus ?? undefined,
      currency: input.currency ?? undefined,
      totalPrice: input.totalPrice ?? undefined,
      lineItemCount: input.lineItemCount,
      syncStatus: "SYNCED",
      lastEvent: input.lastEvent ?? undefined,
    },
  });

  return toRecord(order);
}

export async function getRetailerOrders(shop: string) {
  const orders = await db.retailerOrder.findMany({
    where: { shop },
    orderBy: { createdAt: "desc" },
    take: 100,
  });

  return orders.map(toRecord);
}

type GraphqlOrderNode = {
  id?: string;
  name?: string | null;
  createdAt?: string | null;
  updatedAt?: string | null;
  displayFinancialStatus?: string | null;
  displayFulfillmentStatus?: string | null;
  currencyCode?: string | null;
  currentTotalPriceSet?: { shopMoney?: { amount?: string | null } | null } | null;
  lineItems?: { nodes?: Array<{ quantity?: number | null }> } | null;
};

export async function syncRecentShopifyOrders(
  admin: AdminLike,
  shop: string,
) {
  const response = await admin.graphql(`#graphql
    query RecentCollectiveOrders {
      orders(first: 50, sortKey: CREATED_AT, reverse: true) {
        nodes {
          id
          name
          createdAt
          updatedAt
          displayFinancialStatus
          displayFulfillmentStatus
          currencyCode
          currentTotalPriceSet { shopMoney { amount } }
          lineItems(first: 250) { nodes { quantity } }
        }
      }
    }
  `);

  const payload = (await response.json()) as {
    data?: { orders?: { nodes?: GraphqlOrderNode[] } };
    errors?: Array<{ message?: string }>;
  };

  if (!response.ok || payload.errors?.length) {
    throw new Error(
      payload.errors?.map((error) => error.message).filter(Boolean).join("; ") ||
        `Shopify orders query failed with HTTP ${response.status}`,
    );
  }

  const nodes = payload.data?.orders?.nodes ?? [];
  let synced = 0;

  for (const order of nodes) {
    if (!order.id) continue;
    const lineItemCount = (order.lineItems?.nodes ?? []).reduce(
      (total, line) => total + (line.quantity ?? 0),
      0,
    );

    await upsertRetailerOrder(shop, {
      shopifyOrderId: order.id,
      orderNumber: order.name,
      createdAt: order.createdAt,
      shopifyUpdatedAt: order.updatedAt,
      financialStatus: order.displayFinancialStatus,
      fulfillmentStatus: order.displayFulfillmentStatus,
      currency: order.currencyCode,
      totalPrice: asNumber(order.currentTotalPriceSet?.shopMoney?.amount),
      lineItemCount,
      lastEvent: "orders/sync",
    });
    synced += 1;
  }

  return { synced };
}

export function normalizeOrderWebhook(
  payload: unknown,
  topic: string,
): OrderInput | null {
  if (!payload || typeof payload !== "object") return null;
  const order = payload as Record<string, unknown>;
  const id = order.id;
  if (typeof id !== "number" && typeof id !== "string") return null;

  const lineItems = Array.isArray(order.line_items) ? order.line_items : [];
  const lineItemCount = lineItems.reduce((total, line) => {
    if (!line || typeof line !== "object") return total;
    const quantity = asNumber((line as Record<string, unknown>).quantity);
    return total + (quantity ?? 0);
  }, 0);

  return {
    shopifyOrderId: String(id),
    orderNumber: typeof order.name === "string" ? order.name : null,
    createdAt: typeof order.created_at === "string" ? order.created_at : null,
    shopifyUpdatedAt: typeof order.updated_at === "string" ? order.updated_at : null,
    financialStatus:
      typeof order.financial_status === "string" ? order.financial_status : null,
    fulfillmentStatus:
      typeof order.fulfillment_status === "string" ? order.fulfillment_status : null,
    currency: typeof order.currency === "string" ? order.currency : null,
    totalPrice: asNumber(order.current_total_price ?? order.total_price),
    lineItemCount,
    lastEvent: topic,
  };
}

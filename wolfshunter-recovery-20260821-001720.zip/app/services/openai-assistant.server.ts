import OpenAI from "openai";

import { createPhaseOneFixtureState } from "./merchandising/fixtures";
import {
  getImportedProductPushes,
  getRetailerSettings,
} from "./retailer-commerce.server";
import { getRetailerWorkspace } from "./retailer-workspace.server";

export type AssistantMode =
  | "technical_support"
  | "product_advice"
  | "returns_orders"
  | "merchant_support"
  | "operations_analysis";

const assistantModeValues: AssistantMode[] = [
  "technical_support",
  "product_advice",
  "returns_orders",
  "merchant_support",
  "operations_analysis",
];

export function isAssistantMode(value: unknown): value is AssistantMode {
  return typeof value === "string" && assistantModeValues.includes(value as AssistantMode);
}

interface AssistantContext {
  shop: string;
  catalogCount: number;
  favoriteCount: number;
  importedCount: number;
  productPushes: Array<{
    title: string;
    status: string;
    error: string | null;
  }>;
  retailerSettings: {
    marketCountry: string;
    warehouse: string;
    marginPercent: number;
    requireApproval: boolean;
    automaticPublication: boolean;
  };
}

export interface AssistantResult {
  ok: boolean;
  source: "openai" | "gemini" | "local";
  answer: string;
  mode?: AssistantMode;
  model?: string;
  error?: string;
}

const modelName = (mode: AssistantMode) => {
  if (mode === "operations_analysis") {
    return process.env.OPENAI_ANALYSIS_MODEL?.trim() || process.env.OPENAI_MODEL?.trim() || "gpt-5.6-sol";
  }

  return process.env.OPENAI_MODEL?.trim() || "gpt-5.6-terra";
};

const geminiModelName = (mode: AssistantMode) => {
  if (mode === "operations_analysis") {
    return process.env.GEMINI_ANALYSIS_MODEL?.trim() || process.env.GEMINI_MODEL?.trim() || "gemini-3.7-flash";
  }

  return process.env.GEMINI_MODEL?.trim() || "gemini-3.7-flash";
};

const openAiApiKey = () =>
  process.env.DEIN_NEUER_OPENAI_PROJECT_KEY?.trim() || process.env.OPENAI_API_KEY?.trim();

const geminiApiKey = () => process.env.GEMINI_API_KEY?.trim();

async function requestGemini({
  apiKey,
  mode,
  input,
}: {
  apiKey: string;
  mode: AssistantMode;
  input: string;
}) {
  // Google exposes an OpenAI-compatible endpoint for Gemini. The key is still
  // a Gemini-only key and is never sent to api.openai.com.
  const gemini = new OpenAI({
    apiKey,
    baseURL: "https://generativelanguage.googleapis.com/v1beta/openai/",
    timeout: 15000,
  });
  const response = await gemini.chat.completions.create({
    model: geminiModelName(mode),
    messages: [
      { role: "system", content: instructions(mode) },
      { role: "user", content: input },
    ],
    max_tokens: 900,
  });

  const content = response.choices[0]?.message?.content;
  return typeof content === "string" ? content.trim() : "";
}

export async function getAssistantContext(shop: string): Promise<AssistantContext> {
  const [workspace, settings, pushes] = await Promise.all([
    getRetailerWorkspace(shop),
    getRetailerSettings(shop),
    getImportedProductPushes(shop),
  ]);
  const fixture = createPhaseOneFixtureState(shop);

  return {
    shop,
    catalogCount: fixture.catalog.length,
    favoriteCount: workspace.favoriteProductIds.length,
    importedCount: workspace.importedProductIds.length,
    productPushes: pushes.slice(0, 10).map((push) => ({
      title: push.sourceTitle,
      status: push.status,
      error: push.errorMessage,
    })),
    retailerSettings: {
      marketCountry: settings.marketCountry,
      warehouse: settings.warehouse,
      marginPercent: settings.marginPercent,
      requireApproval: settings.requireApproval,
      automaticPublication: settings.autoPublish,
    },
  };
}

const fallbackAnswer = (message: string, context: AssistantContext, mode: AssistantMode) => {
  const normalized = message.toLowerCase();
  const codeMatch = message.match(/\b(401|403|404|409|422|429|500|501|502|503)\b/);

  if (mode === "technical_support" && codeMatch?.[1] === "401") {
    return "401 bedeutet hier fast immer Authentifizierung: Shopify-Session, App-URL, Client-ID/Secret oder abgelaufener Login passen nicht zusammen. Öffne die App aus dem Shopify-Admin erneut, prüfe danach zuerst /healthz und installiere die App nicht vorschnell neu. Tokens gehören niemals in den Chat.";
  }
  if (mode === "technical_support" && codeMatch?.[1] === "403") {
    return "403 bedeutet Berechtigung oder Cloudflare Access. Prüfe die Access-Policy für collective.wolfshunter.com und ob die Anfrage an die richtige Route geht. Die Händler-App darf dadurch nicht pauschal App-Admin-Rechte erhalten.";
  }
  if (mode === "technical_support" && codeMatch?.[1] === "404") {
    return "404 bedeutet: Diese URL ist auf dem angesprochenen Dienst nicht registriert. Prüfe zuerst Hostname, Pfad und ob Shopify eine interne Prüfroute wie /extensions aufruft. /healthz ist der sichere öffentliche Erreichbarkeitstest; erst danach die geschützte /app-Route testen.";
  }
  if (mode === "technical_support" && codeMatch?.[1] === "501") {
    return "501 bedeutet nicht implementiert. Das ist kein Grund, Daten zu löschen: Funktion als geplante, approval-gated Verbesserung markieren, erst den Scope definieren und dann mit einer reversiblen DRAFT-/Preview-Aktion ergänzen.";
  }
  if (mode === "technical_support" && codeMatch) {
    return `${codeMatch[1]} ist ein technischer Fehlerstatus. Nenne URL, letzte Aktion und Zeitpunkt; prüfe zuerst /healthz und ändere keine Tokens oder Cloudflare-Regeln.`;
  }
  if (mode === "product_advice" || normalized.includes("import") || normalized.includes("produkt")) {
    return `Der aktuelle Händler-Workspace enthält ${context.importedCount} importierte Auswahl(en) und ${context.productPushes.length} protokollierte Shopify-Vorgänge. Nutze Import Lists und erstelle dort je Produkt ausdrücklich einen Shopify-DRAFT; automatische Veröffentlichung bleibt deaktiviert.`;
  }
  if (mode === "returns_orders") {
    return "Im aktuellen Workspace sind noch keine verifizierten Bestell- oder Retourendaten verbunden. Bitte nenne Bestellnummer, Status und die gewünschte nächste Aktion; ich kann den Fall einordnen, aber keine Rückerstattung, Löschung oder Bestellung eigenständig ausführen.";
  }
  if (mode === "merchant_support") {
    return `Der Händler-Workspace ist für ${context.shop} abgegrenzt. Aktuell sind ${context.importedCount} Auswahl(en) importiert; Freigabe ist ${context.retailerSettings.requireApproval ? "aktiv" : "nicht aktiv"}, automatische Veröffentlichung bleibt jedoch sicher deaktiviert. Ich kann Einstellungen und nächste Händler-Schritte erklären.`;
  }

  return "Ich kann die aktuelle App lokal weiter diagnostizieren. Nenne mir Statuscode, URL und was du unmittelbar davor geklickt hast; ich ordne den Fehler ein und schlage nur reversible nächste Schritte vor.";
};

const ethicalGuardrails = `
Ethics and fairness: never declare guilt or fraud from a score, origin, language, category, region, protected characteristic, or other weak proxy. Give evidence, uncertainty, and a fair next review step.
Adverse actions such as bans, refunds, damages decisions, contract termination, withholding money, or payout changes require human review, a reason, and an appeal path.
Emergency balance protection is allowed only when a partner's missed deadline or broken agreement is evidenced and a pre-approved policy permits a reversible, least-invasive safeguard. Record the evidence, deadline, affected orders, notification, and reversal path.
Transparency: state prices, shares, fees, status, data sources, uncertainty, and AI use openly. Never redirect or withhold money outside a confirmed agreement.
`;

const instructions = (mode: AssistantMode) => `
${ethicalGuardrails}
Du bist der sichere WOLFSHUNTER COLLECTIVE ${mode === "operations_analysis" ? "Operations-Analyseassistent" : "Supportassistent"} im Modus ${mode}.
Antworte standardmäßig auf Deutsch, klar und kurz.
Du darfst nur mit den gelieferten, shopbezogenen Betriebsdaten arbeiten. Erfinde keine Shopify-Daten, Preise, Bestellungen, Zugriffsrechte oder Erfolgszustände.
Modusregeln: technical_support erklärt technische Statuscodes und Auth-Flows; product_advice berät zu Katalog, Import-Liste und DRAFT-Produkten; returns_orders behandelt Rückgaben und Bestellfragen, weist aber fehlende Live-Bestelldaten offen aus; merchant_support erklärt Händler-Workspace, Settings, Freigaben und sichere Abläufe; operations_analysis fasst belegte Betriebsdaten für den Betreiber zusammen.
Behandle 401, 403, 404, 409, 422, 429, 500, 501, 502 und 503 unterschiedlich und gib immer Diagnose, sichere nächste Aktion und einen Hinweis, was nicht getan werden soll.
Du darfst niemals Geheimnisse anfordern oder ausgeben. Du darfst keine Cloudflare-Regel, Shopify-Einstellung, Produktveröffentlichung, Löschung, Tokenrotation oder Bestellung eigenständig ausführen.
Produktaktionen bleiben approval-gated: Import List -> expliziter Shopify-DRAFT. Veröffentlichung ist nicht Teil dieses Assistenten.
Wenn Daten fehlen, sage das offen. Bei Unsicherheit: erst prüfen, nicht raten.
`;

export async function askCollectiveAssistant({
  shop,
  message,
  mode = "technical_support",
}: {
  shop: string;
  message: string;
  mode?: AssistantMode;
}): Promise<AssistantResult> {
  const context = await getAssistantContext(shop);
  const localAnswer = fallbackAnswer(message, context, mode);
  const apiKey = openAiApiKey();
  const secondaryApiKey = geminiApiKey();
  const configuredProvider = process.env.AI_PROVIDER?.trim().toLowerCase();
  const provider = configuredProvider === "openai" || configuredProvider === "gemini"
    ? configuredProvider
    : "auto";
  const input = JSON.stringify({
    userMessage: message.slice(0, 4000),
    liveContext: context,
    localDiagnosticBaseline: localAnswer,
  });
  let geminiAutoAttempted = false;

  if (provider === "gemini") {
    if (!secondaryApiKey) {
      return {
        ok: true,
        source: "local",
        answer: `${localAnswer}\n\nGemini ist ausgewählt, aber GEMINI_API_KEY fehlt; lokale Diagnosehilfe bleibt aktiv.`,
        mode,
        error: "Gemini API key missing",
      };
    }

    try {
      const answer = await requestGemini({ apiKey: secondaryApiKey, mode, input });
      return answer
        ? { ok: true, source: "gemini", answer, mode, model: geminiModelName(mode) }
        : { ok: true, source: "local", answer: localAnswer, mode };
    } catch (error) {
      const apiError = error as { status?: number; code?: string; type?: string };
      console.error("[collective-assistant] Gemini request failed", {
        status: apiError.status ?? null,
        code: apiError.code ?? null,
        type: apiError.type ?? null,
      });
      return {
        ok: true,
        source: "local",
        answer: `${localAnswer}\n\nGemini ist momentan nicht erreichbar; die lokale Diagnosehilfe bleibt aktiv.`,
        mode,
        error: "Gemini request failed",
      };
    }
  }

  // In auto mode, product/catalog conversations benefit from Gemini first;
  // technical and operations conversations stay OpenAI-first below. This
  // uses both paid providers by task instead of duplicating every request.
  if (provider === "auto" && mode === "product_advice" && secondaryApiKey) {
    geminiAutoAttempted = true;
    try {
      const answer = await requestGemini({ apiKey: secondaryApiKey, mode, input });
      if (answer) {
        return { ok: true, source: "gemini", answer, mode, model: geminiModelName(mode) };
      }
    } catch (error) {
      const apiError = error as { status?: number; code?: string; type?: string };
      console.error("[collective-assistant] Gemini product route failed", {
        status: apiError.status ?? null,
        code: apiError.code ?? null,
        type: apiError.type ?? null,
      });
    }
  }

  if (!apiKey) {
    if (provider === "auto" && secondaryApiKey && !geminiAutoAttempted) {
      try {
        const answer = await requestGemini({ apiKey: secondaryApiKey, mode, input });
        return answer
          ? { ok: true, source: "gemini", answer, mode, model: geminiModelName(mode) }
          : { ok: true, source: "local", answer: localAnswer, mode };
      } catch (error) {
        const apiError = error as { status?: number; code?: string; type?: string };
        console.error("[collective-assistant] Gemini request failed", {
          status: apiError.status ?? null,
          code: apiError.code ?? null,
          type: apiError.type ?? null,
        });
      }
    }

    return { ok: true, source: "local", answer: localAnswer, mode };
  }

  try {
    const openai = new OpenAI({ apiKey, timeout: 15000 });
    const response = await openai.responses.create({
      model: modelName(mode),
      store: false,
      instructions: instructions(mode),
      input,
      max_output_tokens: 900,
    });
    const answer = response.output_text?.trim() ?? "";
    if (!answer) {
      return { ok: true, source: "local", answer: localAnswer, mode };
    }

    return { ok: true, source: "openai", answer, mode, model: modelName(mode) };
  } catch (error) {
    const apiError = error as {
      status?: number;
      code?: string;
      type?: string;
      param?: string | null;
    };
    console.error("[collective-assistant] OpenAI request failed", {
      status: apiError.status ?? null,
      code: apiError.code ?? null,
      type: apiError.type ?? null,
      param: apiError.param ?? null,
    });

    if (provider === "auto" && secondaryApiKey && !geminiAutoAttempted) {
      try {
        const answer = await requestGemini({ apiKey: secondaryApiKey, mode, input });
        if (answer) {
          return { ok: true, source: "gemini", answer, mode, model: geminiModelName(mode) };
        }
      } catch (fallbackError) {
        const fallbackApiError = fallbackError as { status?: number; code?: string; type?: string };
        console.error("[collective-assistant] Gemini fallback failed", {
          status: fallbackApiError.status ?? null,
          code: fallbackApiError.code ?? null,
          type: fallbackApiError.type ?? null,
        });
      }
    }

    return {
      ok: true,
      source: "local",
      answer: `${localAnswer}\n\nOpenAI ist momentan nicht erreichbar; die lokale Diagnosehilfe bleibt aktiv.`,
      mode,
      error: "OpenAI request failed",
    };
  }
}

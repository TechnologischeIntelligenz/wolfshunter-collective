import type { ActionFunctionArgs, LoaderFunctionArgs } from "react-router";

import { authenticate } from "../shopify.server";
import { isAppAdminSession } from "./app-admin.server";
import { getAppRole } from "./app-role.server";
import { createPhaseOneFixtureState } from "./merchandising/fixtures";
import {
  getRetailerWorkspace,
  updateRetailerWorkspace,
} from "./retailer-workspace.server";
import {
  getImportedProductPushes,
  getRetailerSettings,
} from "./retailer-commerce.server";
import {
  getReadOnlyDiagnostics,
  type ReadOnlyDiagnostics,
} from "./read-only-diagnostics.server";
import {
  getShopifyRetailerMetrics,
  type ShopifyRetailerMetrics,
} from "./shopify-retailer-metrics.server";
import {
  getShopifyCollectionOptions,
  type ShopifyCollectionOption,
} from "./shopify-collection-options.server";

export interface AuthenticatedAppLoaderData {
  authLink: string;
  sessionType: string;
  shop: string;
  favoriteProductIds: string[];
  importedProductIds: string[];
  catalog: ReturnType<typeof createPhaseOneFixtureState>["catalog"];
  retailerSettings: Awaited<ReturnType<typeof getRetailerSettings>>;
  diagnostics: ReadOnlyDiagnostics;
  shopMetrics: ShopifyRetailerMetrics;
  collections: ShopifyCollectionOption[];
  collectiveImportDrafts: number;
  collectiveImportFailures: number;
  appRole: ReturnType<typeof getAppRole>;
  isAppAdmin: boolean;
}

export async function authenticatedAppLoader(
  { request }: LoaderFunctionArgs,
  options: { includeCollections?: boolean } = {},
) {
  const { session, admin } = await authenticate.admin(request);
  const workspace = await getRetailerWorkspace(session.shop);
  const fixture = createPhaseOneFixtureState(session.shop);
  const retailerSettings = await getRetailerSettings(session.shop);
  const diagnostics = await getReadOnlyDiagnostics({ request, session, admin });
  const [shopMetrics, pushes] = await Promise.all([
    getShopifyRetailerMetrics(admin),
    getImportedProductPushes(session.shop),
  ]);
  const collections = options.includeCollections
    ? await getShopifyCollectionOptions(admin)
    : [];

  // Keep persisted affinity limited to products currently available in this
  // retailer's catalog boundary.
  const allowedProductIds = new Set(fixture.catalog.map((product) => product.id));

  return {
    authLink: `/auth/login?shop=${encodeURIComponent(session.shop)}`,
    sessionType: session.isOnline ? "Online session" : "Offline session",
    shop: session.shop,
    favoriteProductIds: workspace.favoriteProductIds.filter((id) => allowedProductIds.has(id)),
    importedProductIds: workspace.importedProductIds.filter((id) => allowedProductIds.has(id)),
    catalog: fixture.catalog,
    retailerSettings,
    diagnostics,
    shopMetrics,
    collections,
    collectiveImportDrafts: pushes.filter((push) => push.status === "DRAFT_CREATED").length,
    collectiveImportFailures: pushes.filter((push) => push.status === "FAILED").length,
    appRole: getAppRole(),
    isAppAdmin: isAppAdminSession(session),
  } satisfies AuthenticatedAppLoaderData;
}

export async function authenticatedWorkspaceAction({ request }: ActionFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const formData = await request.formData();
  const intent = formData.get("intent");
  const productId = formData.get("productId");
  const selected = formData.get("selected");

  if (
    (intent !== "favorite" && intent !== "import") ||
    typeof productId !== "string" ||
    (selected !== "true" && selected !== "false")
  ) {
    return new Response("Invalid workspace update", { status: 400 });
  }

  const fixture = createPhaseOneFixtureState(session.shop);
  const workspace = await updateRetailerWorkspace(session.shop, {
    intent,
    productId,
    selected: selected === "true",
    allowedProductIds: fixture.catalog.map((product) => product.id),
  });

  return workspace;
}

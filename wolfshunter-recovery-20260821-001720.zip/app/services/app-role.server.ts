export type AppRole = "retailer" | "supplier";

export function getAppRole(): AppRole {
  return process.env.APP_ROLE?.trim().toLowerCase() === "supplier"
    ? "supplier"
    : "retailer";
}

type AppAdminSession = {
  email?: string | null;
  shop?: string | null;
};

function configuredValues(name: string) {
  return (process.env[name] ?? "")
    .split(",")
    .map((candidate) => candidate.trim().toLowerCase())
    .filter(Boolean);
}

export function isAppAdminSession(session: unknown) {
  if (!session || typeof session !== "object") return false;

  const candidate = session as AppAdminSession;
  const email = candidate.email?.trim().toLowerCase();
  const shop = candidate.shop?.trim().toLowerCase();
  const allowedEmails = configuredValues("APP_ADMIN_EMAILS");
  const allowedShops = configuredValues("APP_ADMIN_SHOPS");

  return Boolean(
    (email && allowedEmails.includes(email)) ||
      (shop && allowedShops.includes(shop)),
  );
}

export function appAdminConfigurationState() {
  return {
    allowlistConfigured: Boolean(
      process.env.APP_ADMIN_EMAILS?.trim() || process.env.APP_ADMIN_SHOPS?.trim(),
    ),
    allowlistMode: process.env.APP_ADMIN_EMAILS?.trim()
      ? process.env.APP_ADMIN_SHOPS?.trim()
        ? "email + shop"
        : "email"
      : "shop",
    aiProviderConfigured: Boolean(
      process.env.OPENAI_API_KEY?.trim() ||
        process.env.DEIN_NEUER_OPENAI_PROJECT_KEY?.trim() ||
        process.env.GEMINI_API_KEY?.trim(),
    ),
    productWritesScoped: true,
    automaticPublicationEnabled: false,
  };
}

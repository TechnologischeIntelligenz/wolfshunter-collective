import db from "../db.server";

/**
 * Deletes all Collective-owned records for one Shopify shop.
 * Shopify compliance webhooks may be retried, so this is idempotent.
 */
export async function deleteShopData(shop: string) {
  await db.$transaction([
    db.retailerOrder.deleteMany({ where: { shop } }),
    db.importedProductPush.deleteMany({ where: { shop } }),
    db.retailerSettings.deleteMany({ where: { shop } }),
    db.retailerWorkspace.deleteMany({ where: { shop } }),
    db.session.deleteMany({ where: { shop } }),
  ]);
}

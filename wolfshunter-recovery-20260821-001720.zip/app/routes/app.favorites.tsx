import { FavoritesView } from "../features/favorites/favorites-view";
import { useLoaderData } from "react-router";
import {
  authenticatedAppLoader,
  authenticatedWorkspaceAction,
} from "../services/authenticated-app-loader.server";

export { authenticatedAppLoader as loader };
export { authenticatedWorkspaceAction as action };

export default function FavoritesRoute() {
  const loaderData = useLoaderData<typeof authenticatedAppLoader>();

  return (
    <FavoritesView
      initialFavoriteIds={loaderData.favoriteProductIds}
      initialImportedIds={loaderData.importedProductIds}
    />
  );
}

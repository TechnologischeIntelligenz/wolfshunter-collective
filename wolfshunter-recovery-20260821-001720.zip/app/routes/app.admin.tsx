import type { LoaderFunctionArgs } from "react-router";
import { useLoaderData } from "react-router";

import { AdminSettingsView } from "../features/admin/admin-settings-view";
import { appAdminConfigurationState, isAppAdminSession } from "../services/app-admin.server";
import { authenticate } from "../shopify.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  if (!isAppAdminSession(session)) {
    throw new Response("Forbidden", { status: 403 });
  }

  return { configuration: appAdminConfigurationState() };
}

export default function AppAdminRoute() {
  const { configuration } = useLoaderData<typeof loader>();
  return <AdminSettingsView configuration={configuration} />;
}

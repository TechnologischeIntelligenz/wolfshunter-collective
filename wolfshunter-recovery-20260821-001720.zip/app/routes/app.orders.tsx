import { useLoaderData } from "react-router";
import { OrdersView } from "../features/orders/orders-view";
import { authenticatedAppLoader } from "../services/authenticated-app-loader.server";
import {
  getRetailerOrders,
  syncRecentShopifyOrders,
} from "../services/retailer-orders.server";
import { authenticate } from "../shopify.server";

export async function loader(args: Parameters<typeof authenticatedAppLoader>[0]) {
  const data = await authenticatedAppLoader(args);

  try {
    const { admin } = await authenticate.admin(args.request);
    await syncRecentShopifyOrders(admin, data.shop);
  } catch (error) {
    console.error("[orders] recent Shopify order sync failed", {
      name: error instanceof Error ? error.name : "unknown",
    });
  }

  return {
    shop: data.shop,
    orders: await getRetailerOrders(data.shop),
  };
}

export default function OrdersRoute() {
  const data = useLoaderData<typeof loader>();
  return <OrdersView shop={data.shop} orders={data.orders} />;
}

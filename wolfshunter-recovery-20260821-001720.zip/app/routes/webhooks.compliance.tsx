import type { ActionFunctionArgs } from "react-router";

import { authenticate } from "../shopify.server";
import { deleteShopData } from "../services/tenant-data.server";

export const action = async ({ request }: ActionFunctionArgs) => {
  const { topic, shop } = await authenticate.webhook(request);

  // The current app stores no customer/order records. Acknowledge these
  // requests so Shopify knows the compliance contract is implemented.
  if (topic === "customers/data_request" || topic === "customers/redact") {
    console.log(`[compliance] ${topic} acknowledged for ${shop}; no customer data stored`);
    return new Response(null, { status: 200 });
  }

  if (topic === "shop/redact") {
    await deleteShopData(shop);
    console.log(`[compliance] shop data deleted for ${shop}`);
    return new Response(null, { status: 200 });
  }

  return new Response("Unsupported compliance topic", { status: 400 });
};

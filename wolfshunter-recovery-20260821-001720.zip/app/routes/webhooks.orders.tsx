import type { ActionFunctionArgs } from "react-router";

import { authenticate } from "../shopify.server";
import {
  normalizeOrderWebhook,
  upsertRetailerOrder,
} from "../services/retailer-orders.server";

export const action = async ({ request }: ActionFunctionArgs) => {
  const { topic, shop, payload } = await authenticate.webhook(request);
  const order = normalizeOrderWebhook(payload, topic);

  if (!order) {
    console.warn("[orders-webhook] ignored payload without an order id", { topic, shop });
    return new Response("Invalid order payload", { status: 400 });
  }

  // Only a tenant's own order metadata is stored. Customer names, email,
  // phone numbers, addresses, notes, and payment details are intentionally
  // excluded from this first sync path.
  await upsertRetailerOrder(shop, order);
  return new Response(null, { status: 200 });
};

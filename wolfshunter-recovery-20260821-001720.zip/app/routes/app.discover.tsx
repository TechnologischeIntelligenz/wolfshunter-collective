import { DiscoverView } from "../features/discover/discover-view";
import { useLoaderData } from "react-router";
import {
  authenticatedAppLoader,
  authenticatedWorkspaceAction,
} from "../services/authenticated-app-loader.server";

export { authenticatedAppLoader as loader };
export { authenticatedWorkspaceAction as action };

export default function DiscoverRoute() {
  const loaderData = useLoaderData<typeof authenticatedAppLoader>();

  return (
    <DiscoverView
      initialFavoriteIds={loaderData.favoriteProductIds}
      initialImportedIds={loaderData.importedProductIds}
    />
  );
}

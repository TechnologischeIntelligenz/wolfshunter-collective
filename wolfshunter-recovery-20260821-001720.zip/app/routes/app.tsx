import type { ReactNode } from "react";
import type { HeadersFunction } from "react-router";
import {
  Link,
  Outlet,
  redirect,
  useLoaderData,
  useLocation,
  useRouteError,
} from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { AppProvider } from "@shopify/shopify-app-react-router/react";
import { NavMenu } from "@shopify/app-bridge-react";
import { getAppRole } from "../services/app-role.server";

export const loader = async ({ request }: { request: Request }) => {
  // Child routes perform the single request authentication they need. Keeping
  // the layout loader side-effect free avoids concurrent Shopify token refresh
  // calls when an embedded page opens. The parent still owns the unauthenticated
  // entry guard so every /app/* route redirects instead of falling into Shopify's
  // 410 response.
  const url = new URL(request.url);
  const shop = url.searchParams.get("shop");
  const hasSessionToken =
    url.searchParams.has("id_token") || request.headers.has("authorization");

  if (shop && !hasSessionToken) {
    throw redirect(`/auth/login?shop=${encodeURIComponent(shop)}`);
  }

  const appRole = getAppRole();
  const pathname = url.pathname.replace(/\/$/, "");
  const supplierAllowedPaths = new Set(["/app", "/app/support", "/app/admin"]);

  if (appRole === "supplier" && !supplierAllowedPaths.has(pathname)) {
    throw redirect("/app");
  }

  return {
    apiKey: process.env.SHOPIFY_API_KEY || "",
    appRole,
  };
};

function AppNavLink({
  children,
  to,
  home = false,
}: {
  children: ReactNode;
  to: string;
  home?: boolean;
}) {
  const location = useLocation();
  const target = location.search ? `${to}${location.search}` : to;

  return (
    <Link to={target} rel={home ? "home" : undefined}>
      {children}
    </Link>
  );
}

export default function App() {
  const { apiKey, appRole } = useLoaderData<typeof loader>();
  const isSupplier = appRole === "supplier";

  return (
    <AppProvider embedded apiKey={apiKey}>
      <NavMenu>
        <AppNavLink home to="/app">
          {isSupplier ? "Supplier dashboard" : "Dashboard"}
        </AppNavLink>
        {isSupplier ? null : (
          <>
            <AppNavLink to="/app/discover">Discover</AppNavLink>
            <AppNavLink to="/app/favorites">Favorites</AppNavLink>
            <AppNavLink to="/app/import-lists">Import Lists</AppNavLink>
            <AppNavLink to="/app/my-products">My Products</AppNavLink>
            <AppNavLink to="/app/orders">Orders</AppNavLink>
            <AppNavLink to="/app/fulfillment">Fulfillment</AppNavLink>
            <AppNavLink to="/app/tracking">Tracking</AppNavLink>
            <AppNavLink to="/app/analytics">Analytics</AppNavLink>
            <AppNavLink to="/app/subscription">Subscription</AppNavLink>
            <AppNavLink to="/app/settings">Settings</AppNavLink>
          </>
        )}
        <AppNavLink to="/app/support">Support</AppNavLink>
      </NavMenu>
      <Outlet />
    </AppProvider>
  );
}

// Shopify needs React Router to catch some thrown responses, so that their headers are included in the response.
export function ErrorBoundary() {
  return boundary.error(useRouteError());
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};

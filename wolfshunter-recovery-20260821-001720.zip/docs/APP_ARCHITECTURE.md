# WOLFSHUNTER COLLECTIVE app architecture

## Product decision

WOLFSHUNTER COLLECTIVE is primarily a retailer app. The olive-green retailer
workspace stays the main product surface:

`Discover → Favorites → Import List → explicit approval → Shopify DRAFT`

The app never publishes a product automatically. A retailer owns the final
review and publication decision in Shopify Admin.

## Two external roles, one operator boundary

Every connected merchant is treated as exactly one commercial role:

- **Retailer**: discovers supplier products and imports approved products into
  the retailer's Shopify store as DRAFTs.
- **Supplier**: maintains an eligible catalog, wholesale rules, media, and
  inventory for the Collective network.

The app operator/admin is not a merchant role. Admin access is an explicit
server-side `APP_ADMIN_EMAILS` or `APP_ADMIN_SHOPS` allowlist and is kept out
of retailer and supplier navigation unless the signed-in session is
allowlisted.

## Deployment boundary

The current Shopify app configuration is the retailer app. `APP_ROLE=retailer`
is the safe default. The supplier surface is prepared in
`shopify.app.supplier.toml`, but it needs a second Shopify Partner app/client
ID and its own production hostname before it can be deployed.

This separation prevents supplier permissions, retailer product writes, and
operator controls from being mixed in one OAuth client or dashboard.

## Shared platform boundary

The future platform layer can be shared, but every record must carry its
tenant and role boundary. The minimum canonical objects are:

- supplier catalog product and variant;
- retailer catalog mapping and import approval;
- supplier price list and retailer margin policy;
- inventory snapshot with source and freshness;
- order/fulfillment events only after protected-data approval;
- audit and webhook delivery history.

AI may propose catalog text, mappings, diagnostics, and evidence-based risk
flags. It must not bypass tenant checks, Shopify authentication, retailer
approval, publication policy, human dispute review, or an appeal path. A
documented partner breach may trigger only the least-invasive reversible
protection permitted by a pre-approved policy; it may never be inferred from
protected characteristics or a black-box score.

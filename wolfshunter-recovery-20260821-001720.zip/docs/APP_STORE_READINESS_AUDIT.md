# App Store readiness audit

## Current verdict

Not ready for final Shopify App Store submission yet. The retailer shell,
Shopify authentication, read-only diagnostics, support modes, explicit DRAFT
creation, public legal/support routes, admin separation, and minimal order
sync are now implemented foundations. The catalog source is still
fixture-backed and several navigation areas are placeholders.

## Retailer MVP that must remain stable

- olive-green retailer dashboard;
- Shopify session/authentication without 410 on `/app`;
- Discover and Import List scoped to the authenticated shop;
- explicit Shopify DRAFT creation with retry-safe handles;
- no automatic publication;
- retailer settings separate from operator/admin settings;
- support bot with technical, product, returns/orders, and merchant modes.
- recent retailer orders synchronized with minimal non-customer metadata;
- app-admin view separated by server-side email/shop allowlist;
- public privacy, app terms, and support routes.

## Blocking work before submission

1. Replace fixture catalog data with the approved supplier catalog and
   tenant-scoped persistence.
2. Implement or remove placeholder Orders, Fulfillment, Tracking, Analytics,
   and Subscription surfaces from the listing build.
3. Finish Shopify billing configuration in Partner Dashboard. The local
   development flow is prepared for 99 EUR every 30 days with a 14-day trial
   in no-charge test mode; real production billing must be enabled and tested
   through Shopify's approved pricing flow.
4. Move the production database off local SQLite and deploy on durable,
   production-grade hosting.
5. Complete legal review of the app privacy/terms text and protected
   customer-data review before adding customer fields, addresses, or
   fulfillment operations.
6. Create and configure the second Shopify Partner app and domain for the
   supplier portal; it is not represented by the retailer client ID.

The app should be submitted only after these are real product capabilities,
not just dashboard cards.

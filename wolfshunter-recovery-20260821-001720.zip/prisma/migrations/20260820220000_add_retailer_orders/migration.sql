-- CreateTable
CREATE TABLE "RetailerOrder" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "shop" TEXT NOT NULL,
    "shopifyOrderId" TEXT NOT NULL,
    "orderNumber" TEXT,
    "createdAt" DATETIME NOT NULL,
    "shopifyUpdatedAt" DATETIME,
    "financialStatus" TEXT,
    "fulfillmentStatus" TEXT,
    "currency" TEXT,
    "totalPrice" REAL,
    "lineItemCount" INTEGER NOT NULL DEFAULT 0,
    "syncStatus" TEXT NOT NULL DEFAULT 'SYNCED',
    "lastEvent" TEXT,
    "createdInCollectiveAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "RetailerOrder_shop_shopifyOrderId_key" ON "RetailerOrder"("shop", "shopifyOrderId");

-- CreateIndex
CREATE INDEX "RetailerOrder_shop_createdAt_idx" ON "RetailerOrder"("shop", "createdAt");

-- CreateIndex
CREATE INDEX "RetailerOrder_shop_syncStatus_idx" ON "RetailerOrder"("shop", "syncStatus");

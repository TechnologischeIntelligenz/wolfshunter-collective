-- CreateTable
CREATE TABLE "RetailerWorkspace" (
    "shop" TEXT NOT NULL PRIMARY KEY,
    "favoriteProductIds" TEXT NOT NULL DEFAULT '[]',
    "importedProductIds" TEXT NOT NULL DEFAULT '[]',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

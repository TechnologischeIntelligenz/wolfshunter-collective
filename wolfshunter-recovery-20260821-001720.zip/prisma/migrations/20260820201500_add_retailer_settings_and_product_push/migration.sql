-- CreateTable
CREATE TABLE "RetailerSettings" (
    "shop" TEXT NOT NULL PRIMARY KEY,
    "marketCountry" TEXT NOT NULL DEFAULT 'AT',
    "warehouse" TEXT NOT NULL DEFAULT 'Vienna Atelier',
    "marginPercent" REAL NOT NULL DEFAULT 40,
    "requireApproval" BOOLEAN NOT NULL DEFAULT true,
    "autoPublish" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "ImportedProductPush" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "shop" TEXT NOT NULL,
    "sourceProductId" TEXT NOT NULL,
    "sourceTitle" TEXT NOT NULL,
    "sourceCategory" TEXT NOT NULL,
    "retailPrice" REAL NOT NULL,
    "currency" TEXT NOT NULL,
    "idempotencyKey" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'STAGED',
    "shopifyProductId" TEXT,
    "shopifyVariantId" TEXT,
    "errorMessage" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "ImportedProductPush_shop_sourceProductId_key" ON "ImportedProductPush"("shop", "sourceProductId");

-- CreateIndex
CREATE INDEX "ImportedProductPush_shop_status_idx" ON "ImportedProductPush"("shop", "status");

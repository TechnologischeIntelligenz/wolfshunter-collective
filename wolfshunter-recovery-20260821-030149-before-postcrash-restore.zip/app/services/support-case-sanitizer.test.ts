import assert from "node:assert/strict";
import test from "node:test";

import { sanitizeSupportMessage } from "./support-case-sanitizer.ts";

test("support messages redact common secrets and personal contact details", () => {
  const sanitized = sanitizeSupportMessage(
    "Reach me at owner@example.com or +43 660 1234567. Bearer abc.def-ghi_123456789 and sk_test_1234567890123456",
  );

  assert.doesNotMatch(sanitized, /owner@example\.com/);
  assert.doesNotMatch(sanitized, /660 1234567/);
  assert.doesNotMatch(sanitized, /abc\.def-ghi/);
  assert.doesNotMatch(sanitized, /sk_test_/);
  assert.match(sanitized, /\[email redacted\]/);
  assert.match(sanitized, /\[phone redacted\]/);
  assert.match(sanitized, /\[secret redacted\]/);
});

test("support messages remove control characters, normalize spacing, and cap storage", () => {
  const sanitized = sanitizeSupportMessage(`first\u0000\n\tsecond ${"x".repeat(1200)}`);

  assert.match(sanitized, /^first second /);
  assert.equal(sanitized.length, 1000);
  assert.doesNotMatch(sanitized, /[\n\t]/);
});

import { useMemo, useState } from "react";
import { useFetcher, useLocation } from "react-router";

import { FoundationNotice, PageHeader } from "../../components/collective/foundation";
import { ProductCard } from "../../components/collective/product-card";
import { ProductImageStage } from "../../components/collective/product-image-stage";
import { createPhaseOneFixtureState } from "../../services/merchandising/fixtures";
import { createRecommendationProvider } from "../../services/merchandising/rule-based-provider";
import {
  RECOMMENDATION_BUCKET_LABELS,
  type CatalogProduct,
  type CatalogSort,
  type RankedProduct,
  type RecommendationBucket,
  type TenantContext,
} from "../../services/merchandising/types";

const sortLabels: Record<CatalogSort, string> = {
  RECOMMENDED: "Recommended",
  HIGHEST_MARGIN: "Highest margin",
  FASTEST_DELIVERY: "Fastest delivery",
  HIGHEST_STOCK: "Highest stock",
  NEWEST: "Newest",
  LOWEST_WHOLESALE_PRICE: "Lowest wholesale price",
};

const bucketOrder: RecommendationBucket[] = [
  "RECOMMENDED_FOR_STORE",
  "FAST_SHIPPING",
  "HIGH_MARGIN",
  "NEW_ARRIVALS",
  "PREMIUM_SELECTION",
];

type CatalogBucket = RecommendationBucket | "ALL_PRODUCTS";

export function DiscoverView({
  compact = false,
  initialFavoriteIds = [],
  initialImportedIds = [],
  catalog,
  tenant,
  catalogSource = "fallback",
  catalogSyncedAt,
  catalogError = null,
  targetMarginPercent = 40,
}: {
  compact?: boolean;
  initialFavoriteIds?: string[];
  initialImportedIds?: string[];
  catalog?: CatalogProduct[];
  tenant?: TenantContext;
  catalogSource?: "shopify" | "fallback";
  catalogSyncedAt?: string;
  catalogError?: string | null;
  targetMarginPercent?: number;
}) {
  const fallbackFixture = useMemo(() => createPhaseOneFixtureState(), []);
  const resolvedCatalog = catalog ?? fallbackFixture.catalog;
  const resolvedTenant = tenant ?? fallbackFixture.tenant;
  const provider = useMemo(() => createRecommendationProvider(), []);
  const [sort, setSort] = useState<CatalogSort>("RECOMMENDED");
  const [bucket, setBucket] = useState<CatalogBucket>("ALL_PRODUCTS");
  const [search, setSearch] = useState("");
  const [favoriteIds, setFavoriteIds] = useState(initialFavoriteIds);
  const [stagedIds, setStagedIds] = useState(initialImportedIds);
  const [selectedProduct, setSelectedProduct] = useState<RankedProduct | null>(null);
  const fetcher = useFetcher();
  const location = useLocation();

  const persistWorkspaceChange = (
    intent: "favorite" | "import",
    productId: string,
    selected: boolean,
  ) => {
    fetcher.submit(
      { intent, productId, selected: String(selected) },
      {
        method: "post",
        action: `${location.pathname}${location.search}`,
      },
    );
  };

  const affinity = useMemo(
    () => ({ ...fallbackFixture.affinity, favoriteProductIds: favoriteIds }),
    [favoriteIds, fallbackFixture.affinity],
  );

  const searchedCatalog = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return resolvedCatalog;
    return resolvedCatalog.filter((product) =>
      `${product.title} ${product.category}`.toLowerCase().includes(query),
    );
  }, [resolvedCatalog, search]);

  const recommendations = useMemo(
    () =>
      provider.recommend({
        tenant: resolvedTenant,
        products: searchedCatalog,
        affinity,
        bucket: bucket === "ALL_PRODUCTS" ? undefined : bucket,
        sort,
      }),
    [affinity, bucket, provider, resolvedTenant, searchedCatalog, sort],
  );

  const bucketCounts = useMemo(
    () =>
      Object.fromEntries(
        bucketOrder.map((candidate) => [
          candidate,
          provider.recommend({
            tenant: resolvedTenant,
            products: resolvedCatalog,
            affinity,
            bucket: candidate,
            sort: "RECOMMENDED",
          }).products.length,
        ]),
      ) as Record<RecommendationBucket, number>,
    [affinity, provider, resolvedCatalog, resolvedTenant],
  );

  const toggleFavorite = (id: string) => {
    const selected = !favoriteIds.includes(id);
    setFavoriteIds((current) =>
      selected
        ? [...current, id]
        : current.filter((candidate) => candidate !== id),
    );
    persistWorkspaceChange("favorite", id, selected);
  };

  const toggleImportList = (id: string) => {
    const selected = !stagedIds.includes(id);
    setStagedIds((current) =>
      selected
        ? [...current, id]
        : current.filter((candidate) => candidate !== id),
    );
    persistWorkspaceChange("import", id, selected);
  };

  return (
    <main className={`collective-page ${compact ? "collective-page-compact" : ""}`}>
      <PageHeader
        eyebrow="Curated supplier catalog"
        title="Discover products worth carrying."
        description="Transparent economics, delivery context, and evidence-based merchandising signals before anything reaches your store."
        actions={
          <div className="collective-header-statuses">
            <div className={`collective-live-badge ${catalogSource === "shopify" ? "is-live" : "is-fallback"}`}>
              <span aria-hidden="true" />
              <div>
                <small>Catalog source</small>
                <strong>{catalogSource === "shopify" ? "Shopify live" : "Safe preview"}</strong>
              </div>
            </div>
            <div className="collective-list-counter" aria-live="polite">
              <small>Import list</small>
              <strong>{stagedIds.length} staged</strong>
            </div>
          </div>
        }
      />

      <FoundationNotice>
        {catalogSource === "shopify"
          ? `Products and thumbnails are read live from the approved WOLFSHUNTER catalog. Target retail prices use your ${targetMarginPercent}% margin setting.`
          : catalogError ?? "Safe catalog preview is active while the Shopify source reconnects."}{" "}
        Shopify writes happen only through an explicit DRAFT action in Import Lists.
      </FoundationNotice>

      <section className="collective-catalog-toolbar" aria-label="Catalog controls">
        <label className="collective-catalog-search">
          <span>Search live catalog</span>
          <input
            type="search"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Product or category"
          />
        </label>
        <div className="collective-bucket-tabs" role="tablist" aria-label="Recommendation buckets">
          <button
            type="button"
            role="tab"
            aria-selected={bucket === "ALL_PRODUCTS"}
            className={bucket === "ALL_PRODUCTS" ? "is-active" : ""}
            onClick={() => setBucket("ALL_PRODUCTS")}
          >
            <span>All products</span>
            <small>{resolvedCatalog.length}</small>
          </button>
          {bucketOrder.map((candidate) => (
            <button
              key={candidate}
              type="button"
              role="tab"
              aria-selected={bucket === candidate}
              className={bucket === candidate ? "is-active" : ""}
              onClick={() => setBucket(candidate)}
            >
              <span>{RECOMMENDATION_BUCKET_LABELS[candidate]}</span>
              <small>{bucketCounts[candidate]}</small>
            </button>
          ))}
        </div>
        <label className="collective-sort-control">
          <span>Sort</span>
          <select value={sort} onChange={(event) => setSort(event.target.value as CatalogSort)}>
            {Object.entries(sortLabels).map(([value, label]) => (
              <option key={value} value={value}>
                {label}
              </option>
            ))}
          </select>
        </label>
      </section>

      <div className="collective-catalog-meta">
        <span>
          {recommendations.products.length} of {resolvedCatalog.length} products · {sortLabels[sort]}
        </span>
        <span>
          {catalogSource === "shopify" ? "Live sync" : "Preview"}
          {catalogSyncedAt ? ` · ${new Date(catalogSyncedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}` : ""}
        </span>
      </div>

      {recommendations.products.length ? (
        <section className="collective-product-grid" aria-label="Catalog products">
          {recommendations.products.map((rankedProduct) => (
            <ProductCard
              key={rankedProduct.product.id}
              rankedProduct={rankedProduct}
              favorite={favoriteIds.includes(rankedProduct.product.id)}
              staged={stagedIds.includes(rankedProduct.product.id)}
              onToggleFavorite={() => toggleFavorite(rankedProduct.product.id)}
              onToggleImportList={() => toggleImportList(rankedProduct.product.id)}
              onViewDetails={() => setSelectedProduct(rankedProduct)}
            />
          ))}
        </section>
      ) : (
        <div className="collective-inline-empty">
          <strong>No catalog products meet this rule.</strong>
          <span>Clear the search or select All products.</span>
        </div>
      )}

      {selectedProduct ? (
        <div className="collective-detail-backdrop" role="presentation">
          <section
            className="collective-product-detail"
            role="dialog"
            aria-modal="true"
            aria-labelledby="collective-product-detail-title"
          >
            <button
              type="button"
              className="collective-detail-close"
              onClick={() => setSelectedProduct(null)}
              aria-label="Close product details"
            >
              ×
            </button>
            <ProductImageStage
              src={selectedProduct.product.imageUrl}
              alt={selectedProduct.product.title}
              imageCount={selectedProduct.product.imageCount}
              variantImageUrls={selectedProduct.product.variantImageUrls}
              eager
            />
            <div className="collective-detail-copy">
              <p className="collective-eyebrow">{selectedProduct.product.category}</p>
              <h2 id="collective-product-detail-title">
                {selectedProduct.product.title}
              </h2>
              <p>
                This product view exposes the exact evidence inputs. It never
                claims popularity, trending status, or sales performance without
                verified data.
              </p>
              <dl className="collective-score-breakdown">
                {Object.entries(selectedProduct.score.breakdown).map(([label, value]) => (
                  <div key={label}>
                    <dt>{label.replace(/([A-Z])/g, " $1")}</dt>
                    <dd>{value}</dd>
                  </div>
                ))}
              </dl>
              <div className="collective-detail-reasons">
                {selectedProduct.score.reasons.map((reason) => (
                  <span key={reason}>{reason}</span>
                ))}
              </div>
              <p className="collective-detail-note">
                Imports are created as Shopify DRAFT products only after explicit review in Import Lists. Publication is never automatic.
              </p>
            </div>
          </section>
        </div>
      ) : null}
    </main>
  );
}

export interface ShopifyAdminProduct {
  id: string;
  title: string;
  handle: string;
  status: string;
  vendor: string;
  productType: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
  totalInventory: number;
  variantCount: number;
  imageCount: number;
  images: Array<{
    url: string;
    altText: string | null;
  }>;
  priceRange: {
    minimum: number;
    maximum: number;
    currency: string;
  } | null;
}

export interface ShopifyAdminCollection {
  id: string;
  title: string;
  handle: string;
  updatedAt: string;
}

export interface ShopifyAdminCatalog {
  source: "shopify" | "unavailable";
  products: ShopifyAdminProduct[];
  collections: ShopifyAdminCollection[];
  error: string | null;
}

type ShopifyMoney = {
  amount?: string | null;
  currencyCode?: string | null;
};

type RawShopifyAdminProduct = Omit<
  ShopifyAdminProduct,
  "variantCount" | "imageCount" | "images" | "priceRange"
> & {
  mediaCount?: { count?: number | null } | null;
  variantsCount?: { count?: number | null } | null;
  media?: {
    nodes?: Array<{
      alt?: string | null;
      preview?: {
        image?: { url?: string | null; altText?: string | null } | null;
      } | null;
    }>;
  } | null;
  priceRangeV2?: {
    minVariantPrice?: ShopifyMoney | null;
    maxVariantPrice?: ShopifyMoney | null;
  } | null;
};

type CatalogPayload = {
  products?: { nodes?: RawShopifyAdminProduct[] } | null;
  collections?: { nodes?: ShopifyAdminCollection[] } | null;
};

const toNumber = (value: string | null | undefined) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
};

function normalizeProduct(product: RawShopifyAdminProduct): ShopifyAdminProduct {
  const images = (product.media?.nodes ?? [])
    .map((media) => ({
      url: media.preview?.image?.url?.trim() ?? "",
      altText: media.alt ?? media.preview?.image?.altText ?? null,
    }))
    .filter((image) => image.url);
  const minimum = toNumber(product.priceRangeV2?.minVariantPrice?.amount);
  const maximum = toNumber(product.priceRangeV2?.maxVariantPrice?.amount);
  const currency =
    product.priceRangeV2?.minVariantPrice?.currencyCode ??
    product.priceRangeV2?.maxVariantPrice?.currencyCode;

  return {
    id: product.id,
    title: product.title,
    handle: product.handle,
    status: product.status,
    vendor: product.vendor,
    productType: product.productType,
    tags: product.tags ?? [],
    createdAt: product.createdAt,
    updatedAt: product.updatedAt,
    totalInventory: Math.max(0, product.totalInventory ?? 0),
    variantCount: product.variantsCount?.count ?? 0,
    imageCount: product.mediaCount?.count ?? images.length,
    images,
    priceRange:
      minimum !== null && maximum !== null && currency
        ? { minimum, maximum, currency }
        : null,
  };
}

export async function getShopifyAdminCatalog(
  admin: { graphql: (query: string) => Promise<Response> },
): Promise<ShopifyAdminCatalog> {
  try {
    const response = await admin.graphql(`#graphql
      query WolfshunterAdminCatalog {
        products(first: 50, sortKey: UPDATED_AT, reverse: true) {
          nodes {
            id
            title
            handle
            status
            vendor
            productType
            tags
            createdAt
            updatedAt
            totalInventory
            variantsCount { count }
            mediaCount { count }
            priceRangeV2 {
              minVariantPrice { amount currencyCode }
              maxVariantPrice { amount currencyCode }
            }
            media(first: 4, query: "media_type:IMAGE", sortKey: POSITION) {
              nodes {
                alt
                preview { image { url altText } }
              }
            }
          }
        }
        collections(first: 25) {
          nodes {
            id
            title
            handle
            updatedAt
          }
        }
      }
    `);
    const payload = (await response.json()) as {
      data?: CatalogPayload;
      errors?: Array<{ message?: string }>;
    };

    if (!response.ok || payload.errors?.length || !payload.data) {
      const message = payload.errors
        ?.map((error) => error.message)
        .filter(Boolean)
        .join("; ");
      throw new Error(message || `Shopify catalog HTTP ${response.status}`);
    }

    return {
      source: "shopify",
      products: (payload.data.products?.nodes ?? []).map(normalizeProduct),
      collections: payload.data.collections?.nodes ?? [],
      error: null,
    };
  } catch (error) {
    console.error("[admin-catalog] Shopify read-only catalog query failed", {
      name: error instanceof Error ? error.name : "unknown",
      message: error instanceof Error ? error.message.slice(0, 180) : "unknown",
    });

    return {
      source: "unavailable",
      products: [],
      collections: [],
      error: "Der Shopify-Katalog ist momentan nicht erreichbar.",
    };
  }
}

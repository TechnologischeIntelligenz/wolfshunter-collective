CREATE TABLE "SupportCase" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "shop" TEXT NOT NULL,
    "mode" TEXT NOT NULL,
    "messagePreview" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'ANSWERED',
    "source" TEXT NOT NULL,
    "model" TEXT,
    "errorCode" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

CREATE INDEX "SupportCase_shop_createdAt_idx" ON "SupportCase"("shop", "createdAt");
CREATE INDEX "SupportCase_status_createdAt_idx" ON "SupportCase"("status", "createdAt");
